import 'dart:ui';

class StorePageInfoState {
  final int? index;
  final String? name;
  final Color? color;

  StorePageInfoState(
      {this.index, this.name, this.color = const Color(0xFF5d69b3)});
}
